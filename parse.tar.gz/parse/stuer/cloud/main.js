Parse.Cloud.define("requestSession", function(request,response) {

  var sessionId = request.params.sessionId;
  var student_uuid = request.params.student_uuid;
  var userSessionQuery = new Parse.Query('session');

  console.log(student_uuid)
  var userStudentQuery = new Parse.Query(Parse.User);
  userStudentQuery.equalTo('objectId',student_uuid);
  var userStudentName;
  userStudentQuery.find().then( function(userStudent) {
  	userStudentName= userStudent[0].get("username");
  });
  
  
  userSessionQuery.equalTo("sid",sessionId);
  userSessionQuery.find({
  	success: function(sessionObject) {
    		
    		var activity = sessionObject[0].get("activity");
		var userQuery = new Parse.Query(Parse.User);
		var teacher_uuid = sessionObject[0].get("user_uuid");
		userQuery.equalTo('objectId', teacher_uuid);
		userQuery.find({
			success: function(userObject){
			
				var pushQuery = new Parse.Query(Parse.Installation);
				var teacher_name = userObject[0].get("username");
				pushQuery.equalTo('username', teacher_name);
			
				Parse.Push.send({
					where: pushQuery,
					data: {
				  	   "alert" : "Request from user " + userStudentName + "for activity " + activity ,
					   "student_uuid" : student_uuid,
					   "session_id" : sessionId,
					   "type" : "sessionRequest"
				  	}
			  	}); 
				response.success("Request Sent");
			},
		  	error: function(object, error) {
				response.error("Error" + error);
		  		// error is an instance of Parse.Error.
		  	}
  		});
		}
	});
});	

Parse.Cloud.define("confirmSession", function(request,response) {


  var sessionId = request.params.sessionId;
  var student_uuid = request.params.student_uuid;
  
  var userSessionQuery = new Parse.Query('session');
  userSessionQuery.equalTo("sid",sessionId);
  userSessionQuery.find({
  	success: function(sessionObject) {
    		var teacher_uuid = sessionObject[0].get("user_uuid");
    		var session_id = sessionObject[0].get("sid");
    		var activity = sessionObject[0].get("activity");
		
		
		  var userTeacherQuery = new Parse.Query(Parse.User);
		  userTeacherQuery.equalTo('objectId',teacher_uuid);
		  var userTeacherName;
		  userTeacherQuery.find().then( function(userTeacher) {
		  	userTeacherName= userTeacher[0].get("username");
		  });
		
		
		var transaction = Parse.Object.extend("transaction");
		var transObj = new transaction();
		transObj.set("teacher_uuid",teacher_uuid);
		transObj.set("student_uuid",student_uuid);
		transObj.set("teacher_confirm",false);
		transObj.set("student_confirm",false);
		transObj.set("tid_state",true);
		transObj.set("session_id",session_id);
		
		transObj.save(null,{
			success: function (object) { 
				console.log("Success");
				var userQuery = new Parse.Query(Parse.User);
				userQuery.equalTo("objectId", student_uuid);


				userQuery.find({
					success: function(userObject){
						console.log("Starting");

						var username = userObject[0].get("username");

						console.log("username:"+ username);

						var pushQuery = new Parse.Query(Parse.Installation);
						pushQuery.equalTo('username', username);

						Parse.Push.send({
							where: pushQuery,
							data: {
								"alert" : "Request for " + activity + " from " + userTeacherName + " has been accepted",
								"type" : "sessionAcknowledge"
							}
						});        
						response.success(object);
					}, 
					error: function (object, error) { 
						console.log("Error");
						response.error("Error" + error);
					}
				});
			},	
			error: function(object, error) {
				console.log("Error2");
				response.error("Error:" + error);
			}
		});

	}
  });
});

Parse.Cloud.afterSave("transaction", function(request) {

  var student_confirm = request.object.get("student_confirm");
  var teacher_confirm = request.object.get("teacher_confirm");
  var tid_state = request.object.get("tid_state");
  var session_id = request.object.get("session_id");
  
  console.log(student_confirm+ " "+ teacher_confirm+" " +tid_state);
  if(student_confirm == true && teacher_confirm == true && tid_state == true){
  	var teacher_uuid = request.object.get("teacher_uuid");
  	var student_uuid = request.object.get("student_uuid");
  	console.log("Executing Transaction");
  	var userSessionQuery = new Parse.Query("session");
  	userSessionQuery.equalTo("sid",session_id);
  	var fare;
  	var sessionObject;
  	userSessionQuery.find({
  	success: function(sessionObj) {
  			console.log("found sessionobj");
  			fare = sessionObj[0].get("fare");
  			sessionObj[0].set("sid_state",false);
	  		sessionObject = sessionObj[0];
	  		
		console.log("step 1");
		var teacherWalletQuery = new Parse.Query('wallet');
		teacherWalletQuery.equalTo("user_uuid",teacher_uuid);
	
		var studentWalletQuery = new Parse.Query('wallet');
		studentWalletQuery.equalTo("user_uuid",student_uuid);
	
		console.log("step 2");
		var teacherObject;
		teacherWalletQuery.find({
		success: function(teacherObj) {
			console.log("ADDING Up Balance to Teacher Transaction" + fare);
			console.log("Balance:"+teacherObj[0].get("balance"));
			var new_fare = teacherObj[0].get("balance") + fare;
			console.log(new_fare);
		  	teacherObj[0].set("balance",new_fare);
		  	teacherObject = teacherObj[0];
		  	console.log("persisting add");
			
			teacherObject.save({balance: new_fare}, {
				success: function(object){
				console.log("persisting sav");
				},
				error: function(object, error){
				console.log("persisting sav fail " + error.message);
				}
				
			});
		  	
		},
		error: function(error){
			console.log("error: " + error.message);
		}}
		);
		console.log("step 3");		
		console.log("step 4");
	
		var studentObject;
		var waiter_main4 = studentWalletQuery.find().then(function(studentObj){
			console.log("REMOVING Up Balance from Student Transaction" + fare);
			console.log("Balance:"+studentObj[0].get("balance"));	
			var studentBalance = studentObj[0].get("balance");		
			studentObj[0].set("balance", studentBalance - fare);
			studentObject = studentObj[0];
		}); 
	
		var waiter_main5;
		Parse.Promise.when([waiter_main4]).then(function() {
			console.log("persisting remove");
			waiter_main5 = studentObject.save();
		});
		
	
		request.object.set("tid_state", false);
		var waiter_main6 = request.object.save();
	
	
		var waiter_main7 = sessionObject.save();
		
		Parse.Promise.when([waiter_main6,waiter_main7]).then(function() {
	  	console.log("Transaction Update Sucessful");
		});
	
  	},
  	
  	error: function(error){
  		console.log("error2: " + error.message);
  	}
  	
  	});
	
	
	
  }
});
	


Parse.Cloud.define("confirmComplete", function(request,response) {
	var sessionId = request.params.sessionId;
  	var student_uuid = request.params.student_uuid;
  	
  	var userQuery = new Parse.Query(Parse.User);
	userQuery.equalTo('objectId', student_uuid);
	
	var student_username;
	
	var waiter1 = userQuery.find().then( function(studentObj){
			student_username = studentObj[0].get('username');
	}); 
	var waiter2 = Parse.Promise.when(waiter1).then( function() {
		var pushQuery = new Parse.Query(Parse.Installation);
		pushQuery.equalTo('username', student_username);
		Parse.Push.send({
			where: pushQuery,
			data: {
				"alert" : "Request for " + sessionId + " from " + student_username + " has been completed",
				"type" : "sessionComplete",
				"session_id" : sessionId
			}
		});
	});
	
	Parse.Promise.when(waiter2).then( function(result) {
		response.success({result:true});
	},function(error) {
   		 response.error(error); 
   	}); 
});



Parse.Cloud.job("sessionInvalidationJob", function(request, status) {
  // Set up to modify user data
  // Query for all users
  var query = new Parse.Query("session");
  query.each(function(session) {
      var sessionStartTime = session.get("time");
      var duration = session.get("duration");
      var dateSessionStartTime = new Date(sessionStartTime);
      dateSessionStartTime.setHours(dateSessionStartTime.getHours() + duration);
      var sessionEndTime = dateSessionStartTime;
      // Set and save the change
      var currentTime = Date.now();
      console.log("Reading Sessions");
      if( sessionEndTime < currentTime){
      		console.log("Invalidating Session " + session.get("activity"));
      		console.log("Session End Time :" + sessionEndTime.toISOString());
      		session.set("sid_state",false);
      		session.save();
      
      	      var student_uuid;
	      var transactionQuery = new Parse.Query('transaction');
	      transactionQuery.equalTo("session_id",session.get("sid"));
	      transactionQuery.equalTo("tid_state",true);
	      transactionQuery.find().then(function(transactionObject) {
		      transactionObject[0].set("teacher_confirm",true);
		      student_uuid = transactionObject[0].get("student_uuid");
		      
		      transactionObject[0].save();
	      });
	      
	      var sessionId = session.get("sid");

	      var userQuery = new Parse.Query(Parse.User);
	      userQuery.equalTo('objectId', student_uuid);
	      var student_username;

	      var waiter1 = userQuery.find().then( function(studentObj){
	      student_username = studentObj[0].get('username');
	      }); 
	      var waiter2 = Parse.Promise.when(waiter1).then( function() {
	      var pushQuery = new Parse.Query(Parse.Installation);
	      pushQuery.equalTo('username', student_username);
	      
	      Parse.Push.send({
			where: pushQuery,
			data: {
				"alert" : "Request for " + sessionId + " from " + student_username + " has been completed",
				"type" : "sessionComplete",
				"session_id" : sessionId
			}
			});
	      });
      
      }
      
  }).then(function() {
    status.success("Migration completed successfully.");
  }, function(error) {
    status.error("Uh oh, something went wrong.");
  });
});
